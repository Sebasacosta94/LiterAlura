INSERT INTO book (title, author, description, publisher) VALUES ('Example Book', 'John Doe', 'Description of example book', 'Example Publisher');
