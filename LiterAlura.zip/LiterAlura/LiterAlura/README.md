# LiterAlura

Proyecto de catálogo de libros utilizando Spring Boot 3.2.6 y JDK 17.

## Requisitos

- JDK 17
- Maven

## Configuración

1. Clona el repositorio.
2. Navega a la carpeta del proyecto.
3. Ejecuta `mvn clean install` para instalar las dependencias.
4. Ejecuta `mvn spring-boot:run` para iniciar la aplicación.

## Endpoints

- `GET /books`: Obtener todos los libros.
- `POST /books`: Crear un nuevo libro.

## Notas

Este proyecto consume una API de libros, manipula datos JSON, y guarda información en una base de datos H2.
